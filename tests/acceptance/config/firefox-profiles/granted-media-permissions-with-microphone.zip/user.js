user_pref("media.navigator.permission.disabled", true);
user_pref("media.navigator.streams.fake", true);
user_pref("media.navigator.video.enabled", false);
